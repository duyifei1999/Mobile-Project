
//Author: XiaoHan Zhang

import java.util.*;


public class shipyard {	
	//Key: shipname
	//Value: price, width, length, hp
	private static HashMap<String, int[]> shipClassList = new HashMap<String, int[]>();
	

	//---------------------------Initialization---------------------------
	public static void loadShipMenu() {
		//Unit stats are defined here
		shipClassList.put("frigate", new int[]{100,1,1,1});
		shipClassList.put("cruiser", new int[]{150,1,2,2});
		shipClassList.put("landFortress", new int[]{200,1,3,3});
		shipClassList.put("transport", new int[]{50,2,2,1});
		shipClassList.put("carrier", new int[]{125,2,2,3});
		shipClassList.put("dreadnought", new int[]{250,1,4,4});
		shipClassList.put("seaFortress", new int[]{275,2,3,5});
		shipClassList.put("city", new int[]{175,3,3,4});
		shipClassList.put("flagship", new int[]{300,3,3,6});
	}
	

	//---------------------------Get and set functions---------------------------
	public static int getBuildCost(String className) {
		if (shipClassList.get(className) == null) {
			System.out.println("Ship class does not exist: " + className + "!");
		}
		return shipClassList.get(className)[0];
	}	
	
	public static int getSmallestBuildCost() {
		int smallestCost = 99999;
		for (int[] shipStats : shipClassList.values()) {
			if (shipStats[0] < smallestCost) {
				smallestCost = shipStats[0];
			}
		}
		return smallestCost;
	}

	public static HashMap<String, int[]> getShipClassList() {
		return shipClassList;
	}
	

	//---------------------------Important functions---------------------------	
	//Return the ship built and credits remaining
	public static List<Object> buildBattleship (String className, int credits) {
		int remainingCredits = credits - getBuildCost(className);
		if (remainingCredits < 0) {
			System.out.println("Insufficient funds!");
			return Arrays.asList(null, credits);
		}
		int[] stats = shipClassList.get(className);
		battleship shipBuilt = new battleship(stats[1],stats[2],stats[3],className);
		//System.out.println("Ship purchased: " + className);
		return Arrays.asList(shipBuilt, remainingCredits);
	}
	
	
	
}
	
