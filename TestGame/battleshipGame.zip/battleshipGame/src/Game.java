import java.util.Random;


public class Game {	

	

	//public static enum Stage {PREPARE, FIGHT};
	//private Stage currentState = Stage.PREPARE;
	public static enum creditOptions {LOW, MID, HIGH, VERYHIGH};
	public static enum sizeOptions {SMALL, MED, LARGE, VERYLARGE};
	private Player bluePlayer;
	private Player redPlayer;
	private boolean bluesTurn;
	public Random rand;
	

	public static void main(String[] args) {
		shipyard.loadShipMenu();
		Game thisGame = new Game(creditOptions.MID, sizeOptions.VERYLARGE, new Random());
		System.out.println("---------Warp jump initiated!----------");
		thisGame.bluePlayer.AIbuildAndPlaceRandomFleet();
		thisGame.redPlayer.AIbuildAndPlaceRandomFleet();
		System.out.println("Blue fleet composition:");
		System.out.println(thisGame.bluePlayer.getSea().fleetToString());
		System.out.println("Red fleet composition");
		System.out.println(thisGame.redPlayer.getSea().fleetToString());
		System.out.println("---------Warp jump complete!----------");
		while(!thisGame.bluePlayer.hasLost() && !thisGame.redPlayer.hasLost()) {			
			if(thisGame.bluesTurn) {
				boolean scoredHit = thisGame.bluePlayer.AIattack();
				thisGame.redPlayer.getSea().updateGrid();
				if (scoredHit) {
					System.out.println("Red fleet have been hit! Ships remaining:");
					System.out.println(thisGame.redPlayer.getSea().fleetToString());
				} else {
					System.out.println("Red fleet evaded enemy attack!");					
				}
			} else {
				boolean scoredHit = thisGame.redPlayer.AIattack();
				thisGame.bluePlayer.getSea().updateGrid();
				if (scoredHit) {
					System.out.println("Blue fleet have been hit! Ships remaining:");
					System.out.println(thisGame.bluePlayer.getSea().fleetToString());
				} else {
					System.out.println("Blue fleet evaded enemy attack!");					
				}
			}			
			thisGame.bluesTurn = !thisGame.bluesTurn;
		}
		if (thisGame.bluePlayer.hasLost()) {
			System.out.println("Blue fleet destroyed!");
		} else {
			System.out.println("Red fleet destroyed!");
		}
	}	
	
		
	Game(creditOptions creditOption, sizeOptions sizeOption, Random givenRandom) {
		int mapWidth = 0;
		int mapHeight = 0;
		int startingCredits = 0;
		if (creditOption == creditOptions.LOW) {
			startingCredits = 600;
		} else if (creditOption == creditOptions.MID) {
			startingCredits = 800;			
		} else if (creditOption == creditOptions.HIGH) {
			startingCredits = 1000;			
		} else if (creditOption == creditOptions.VERYHIGH) {
			startingCredits = 1200;			
		}
		if (sizeOption == sizeOptions.SMALL) {
			mapWidth = 8;
			mapHeight = 10;
		} else if (sizeOption == sizeOptions.MED) {
			mapWidth = 10;
			mapHeight = 12;
		} else if (sizeOption == sizeOptions.LARGE) {
			mapWidth = 12;
			mapHeight = 14;
		} else if (sizeOption == sizeOptions.VERYLARGE) {
			mapWidth = 14;
			mapHeight = 16;
		}
		bluePlayer = new Player(mapWidth, mapHeight, startingCredits, this);
		redPlayer = new Player(mapWidth, mapHeight, startingCredits, this);
		rand = givenRandom;
		bluesTurn = rand.nextBoolean();		
	}
	

	//---------------------------Get and set functions---------------------------
	
	public Player getOpponent(Player thisPlayer) {
		if (thisPlayer == bluePlayer) {
			return redPlayer;
		}
		if (thisPlayer == redPlayer) {
			return bluePlayer;
		}
		System.out.println("Game failed to get player opponent!");
		return null;
	}
	
}
	
