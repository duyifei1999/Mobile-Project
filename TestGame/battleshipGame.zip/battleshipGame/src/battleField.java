import java.util.ArrayList;



public class battleField {	

	private int MapWidth;
	private int MapHeight;
	public static enum GridTypes {UNSCOUNTED, EMPTY, HIT, SUNK};
	private GridTypes[][] mapGrid;
	private ArrayList<battleship> fleet = new ArrayList<battleship>();

		
	battleField(int mapWidth, int mapHeight) {
		MapWidth = mapWidth;
		MapHeight = mapHeight;	
		mapGrid = new GridTypes[MapWidth][MapHeight];
		for (int i = 0; i < MapWidth; i++) {			
			for (int j = 0; j < MapHeight; j++) {
				mapGrid[i][j] = GridTypes.UNSCOUNTED;
			}
		}
		
	}	
	

	//---------------------------Get and set functions---------------------------
	//Update grid (so we know which color to show).
	
	public int getWidth() {
		return MapWidth;
	}
	public int getHeight() {
		return MapHeight;
	}
	
	
	public void updateGrid() {
		for (int i = 0; i < MapWidth; i++) {			
			for (int j = 0; j < MapHeight; j++) {
				//These two types of cells do not need updates
				if (mapGrid[i][j] == GridTypes.EMPTY || mapGrid[i][j] == GridTypes.SUNK) {
					continue;
				}
				for (battleship targetShip : fleet) {
					GridTypes shipComponent = targetShip.getCell(new int[] {i, j});
					if (shipComponent != null) {
						//Overwrite the cell condition with ship condition
						mapGrid[i][j] = shipComponent;					
					}
				}
			}
		}
	}
		

	public battleField.GridTypes getCell(int[] coordinates) {
		if (coordinates[0] < 0 || coordinates[1] < 0 || coordinates[0] >= MapWidth || coordinates[1] >= MapHeight) {
			return null;
		}
		return mapGrid[coordinates[0]][coordinates[1]];
	}
	
	public boolean fleetDestroyed() {
		for (battleship targetShip : fleet) {
			if (! targetShip.isSunk()) {
				return false;
			}
		}
		return true;
	}
	
	public String fleetToString() {
		String result = "";
		for (battleship targetShip : fleet) {
			if (! targetShip.isSunk()) {
				result += "[" + targetShip.getName() + " " + targetShip.getHp() + "hp]";
			}
		}
		return result;
	}
	

	

	//---------------------------Important functions---------------------------
	//Return whether placement is legal or not
	public boolean placeBattleship(battleship placedShip, int[] cordinates, boolean horizontal) {
		placedShip.setPosition(cordinates, horizontal);
		for (int[] cellLocation: placedShip.getAllCells()) {
			//Out of map
			if ((cellLocation[0] < 0) || (cellLocation[1] < 0) || (cellLocation[0] >= MapWidth)  || (cellLocation[1] >= MapHeight)) {
				return false;
			}
			//Collision
			if (isOccupied(fleet, cellLocation)) {
				return false;
			}
		}
		//If no collision or out-of-map have been detected
		fleet.add(placedShip);
		return true;
	}
	
	//Return whether something is hit
	public boolean hitCell(int[] coordinates) {
		if (mapGrid[coordinates[0]][coordinates[1]] != GridTypes.UNSCOUNTED) {
			System.out.println("Cannot attack damaged or sunk components!");
			return false;
		}
		for (battleship targetShip : fleet) {
			if (targetShip.getCell(new int[] {coordinates[0],coordinates[1]}) != null) {
				targetShip.takeHit(new int[] {coordinates[0],coordinates[1]});
				if (targetShip.isSunk()) {
					fleet.remove(targetShip);
				}
				return true;
			}
		}
		mapGrid[coordinates[0]][coordinates[1]] = GridTypes.EMPTY;
		return false;
	}

	
	
	//---------------------------Helper functions---------------------------
	public boolean isOccupied(ArrayList<battleship> targetFleet, int[] cellLocation) {
		for (battleship targetShip : targetFleet) {
			if (targetShip.getCell(cellLocation) != null) {			
				return true;
			}
		}
		return false;
	}
	
	
}
	
