import java.util.ArrayList;

//Author: XiaoHan Zhang


public class battleship {	

	private int ShipWidth;
	private int ShipHeight;
	private int XCordinate = 0; //The top left cornor of the ship. 
	private int YCordinate = 0; //The top left cornor of the ship. 
	private boolean Horizontal;
	private String Name;
	private int hp;
	//Here is the condition of each cell. 
	private battleField.GridTypes[][] shipCompnents;
	
	
	
	
	
	public battleship(int shipWidth, int shipHeight, int maxHP, String name) {
		ShipWidth = shipWidth;
		ShipHeight = shipHeight;	
		Name = name;
		hp = maxHP;
		
	}


	//---------------------------Get and set functions---------------------------
	public battleField.GridTypes getCell(int[] coordinates) {
		for (int i = 0; i < shipCompnents.length; i++) {
			for (int j = 0; j < shipCompnents[0].length; j++) {
				int currentX = XCordinate + i;
				int currentY = YCordinate + j;
				if (coordinates[0] == currentX && coordinates[1] == currentY) {
					//System.out.println("Cell " + coordinates[0] + "," + coordinates[1] + " has collision when i, j equals: " + i + "," + j);
					//System.out.println("Stats: " + coordinates[0] + "," + coordinates[1] + ","  + currentX  + "," + currentY);
					return shipCompnents[i][j];
				}
			}
		}		
		return null;
	}
	public ArrayList<int[]> getAllCells() {
		ArrayList<int[]> result = new ArrayList<>();
		for (int i = 0; i < shipCompnents.length; i++) {
			for (int j = 0; j < shipCompnents[0].length; j++) {
				int currentX = XCordinate + i;
				int currentY = YCordinate + j;
				result.add(new int[] {currentX, currentY});
			}
		}
		return result;
	}
	public boolean isSunk() {	
		return hp <= 0;
	}
	public int getHp() {	
		return hp;
	}
	public String getName() {	
		return Name;
	}
	
	
	


	//---------------------------Important functions---------------------------
	public void setPosition(int[] cordinates, boolean horizontal) {
		XCordinate = cordinates[0];
		YCordinate = cordinates[1];	
		Horizontal = horizontal;	
		int xSpam = ShipWidth;	
		int ySpam = ShipHeight;
		if (Horizontal) {
			int temp = xSpam;
			xSpam = ySpam;
			ySpam = temp;
		}
		shipCompnents = new battleField.GridTypes[xSpam][ySpam];
		for (int i = 0; i < xSpam; i++) {
			for (int j = 0; j < ySpam; j++) {
				shipCompnents[i][j] = battleField.GridTypes.UNSCOUNTED;
			}
		}
	}
	

	//Return hit or not hit
	public boolean takeHit(int[] cordinates) {
		if (shipCompnents == null) {
			System.out.println("A ship haven't been placed on map cannot be hit!");
		}
		for (int i = 0; i < shipCompnents.length; i++) {
			for (int j = 0; j < shipCompnents[0].length; j++) {
				int currentX = XCordinate + i;
				int currentY = YCordinate + j;
				if (cordinates[0] == currentX && cordinates[1] == currentY) {
					if (shipCompnents[i][j] == battleField.GridTypes.UNSCOUNTED) {
						shipCompnents[i][j] =  battleField.GridTypes.HIT;
						hp --;
						checkSunk();
						return true;  //Is hit
					} else {
						System.out.println("One of the ships' components is hit twice!");
					}
				}
			}
		}
		return false; //Isn't hit
	}
	
	
	
	//---------------------------Helper functions---------------------------
	private boolean checkSunk() {
		if (hp < 1) {
			for (int i = 0; i < shipCompnents.length; i++) {
				for (int j = 0; j < shipCompnents[0].length; j++) {
					shipCompnents[i][j] = battleField.GridTypes.SUNK;
				}
			}
			return true;
		}
		return false;
	}
	
}
	
