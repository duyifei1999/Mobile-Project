//Author: XiaoHan Zhang
import java.util.*;


public class Player {	


	private Game currentGame;
	private battleField mySea;
	private int credits;
	private battleship unplacedShip;


		
	Player(int mapWidth, int mapHeight, int startingCredits, Game thisGame) {
		credits = startingCredits;
		mySea = new battleField(mapWidth, mapHeight);
		currentGame = thisGame;
	}
	

	//---------------------------Get and set functions---------------------------
	public battleField getSea() {
		return mySea;
	}
	
	public boolean hasLost() {
		return mySea.fleetDestroyed();
	}
	
	
	
	//---------------------------Important functions---------------------------	
	//Return either successful or not
	public boolean purchase(String className) {
		if (unplacedShip != null) {
			System.out.println("Cannot purchase a ship when another is not placed!");
			return false;
		}
		if (credits >= shipyard.getShipClassList().get(className)[0]) {
			List<Object> results = shipyard.buildBattleship(className, credits);
			unplacedShip = (battleship) results.get(0);
			credits = (int) results.get(1);
			if (unplacedShip == null) {
				System.out.println("Player failed to purchase ship!");
			} else {
			return true;
			}
		}
		return false;		
	}
	
	public boolean place(int[] cordinates, boolean horizontal) {
		if (unplacedShip == null) {
			System.out.println("No ship can be placed!");
			return false;
		}
		boolean succuess = mySea.placeBattleship(unplacedShip, cordinates, horizontal);
		if (succuess) {
			unplacedShip = null;
		}
		return succuess;
	}

	public boolean sell() {
		if (unplacedShip == null) {
			System.out.println("No ship can be sold!");
			return false;
		}
		unplacedShip = null;
		credits += shipyard.getBuildCost(unplacedShip.getName());
		return true;
	}
	
	
	public boolean attack(int[] cordinates) {
		if ((cordinates[0] < 0) || (cordinates[1] < 0) || (cordinates[0] >= mySea.getWidth())  || (cordinates[1] >= mySea.getHeight())) {
			System.out.println("Illeal location to hit!");
			return false;
		}
		return currentGame.getOpponent(this).getSea().hitCell(cordinates);
	}
	

	//---------------------------AI functions---------------------------
	public boolean AIbuildAndPlaceRandomFleet() {
		while(AIbuildAndPlaceRandomShip()) {
			continue;
		}
		if (credits < 100 && unplacedShip == null && !hasLost()) {
			return true;
		} else {
			System.out.println("AI ship construction or placement failed!");
			System.out.println("Credits remaining: " + credits);
			System.out.println("Has unplaced Ship: " + (unplacedShip != null));
			return false;
		}
	}	
	
	public boolean AIbuildAndPlaceRandomShip() {
		if (! AIbuildRandomShip()) {
			//System.out.println("Purchase failed with remaining credits: " + credits);
			return false;
		}
		if (! AIplaceRandomShip()) {
			//System.out.println("Placement failed!");
			return false;			
		}
		return true;		
	}
	
	//Will build ships randomly. Small ships will be chosen slightly more often as only they are available when not much credits remaining.
	public boolean AIbuildRandomShip() {
		Set<String> shipClasses = shipyard.getShipClassList().keySet();
		//AI might run out of space when trying to place this!
		shipClasses.remove("transport");
		ArrayList<String> buildOptions = new ArrayList<>();
		for(String shipClass : shipClasses) {
			if (shipyard.getBuildCost(shipClass) <= credits) {
				buildOptions.add(shipClass);
			}
		}
		if (buildOptions.size() < 1) {
			return false;
		}
		Collections.shuffle(buildOptions, currentGame.rand);
		return purchase(buildOptions.get(0));
	}
	
	public boolean AIplaceRandomShip() {
		//The order of cells are random, so placement is random
		ArrayList<int[]> coordiatesList = new ArrayList<>();
		for (int i = 0; i < mySea.getWidth(); i++) {			
			for (int j = 0; j < mySea.getHeight(); j++) {
				coordiatesList.add(new int[]{i,j});
			}
		}
		Collections.shuffle(coordiatesList, currentGame.rand);
		for (int[] thisCell : coordiatesList) {
			//Either vertically or horizontally
			if (place(thisCell, false)) {
				return true;
			}
			if (place(thisCell, true)) {
				return true;
			}
		}
		System.out.println("AI ship placement failed! Possible coordinates attempted: "+coordiatesList.size());
		return false;
	}
	
	
	public boolean AIattack() {
		return attack(AIchooseTarget());
	}
	
	
	
	public int[] AIchooseTarget() {
		battleField strikeArea = currentGame.getOpponent(this).getSea();
		ArrayList<int[]> coordinates = new ArrayList<>();
		for (int i = 0; i < mySea.getWidth(); i++) {			
			for (int j = 0; j < mySea.getHeight(); j++) {
				int[] coordiate = new int[]{i,j};
				//Can only attack this type of tile
				if (strikeArea.getCell(coordiate) != battleField.GridTypes.UNSCOUNTED) {
					continue;
				}
				if (strikeArea.getCell(new int[]{i+1,j})==battleField.GridTypes.HIT || strikeArea.getCell(new int[]{i-1,j})==battleField.GridTypes.HIT || strikeArea.getCell(new int[]{i,j+1})==battleField.GridTypes.HIT || strikeArea.getCell(new int[]{i,j-1})==battleField.GridTypes.HIT) {
					//Choose directly if there is a hit (but not sunk) cell nearby.
					return coordiate;
				}
				coordinates.add(new int[]{i,j});
			}
		}
		for (int i = 0; i < coordinates.size(); i++) {
			if (coordinates.size() < 5) {
				break;
			}
			boolean hasScountedNeighbour = false;
			for (int x = coordinates.get(i)[0]-1; x <= coordinates.get(i)[0]+1; x++) {
				for (int y = coordinates.get(i)[0]-1; x <= coordinates.get(i)[0]+1; x++) {
					int[] neighbour = new int[]{x,y};
					if (strikeArea.getCell(neighbour) != battleField.GridTypes.UNSCOUNTED) {
						hasScountedNeighbour = true;
						coordinates.remove(i);
						break;
					}
				}
				if (hasScountedNeighbour) {
					break;
				}
			}			
		}
		int id = currentGame.rand.nextInt(coordinates.size());
		return coordinates.get(id);		
	}
	
	
	
	
}
	
